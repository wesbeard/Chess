/*
 * Wes Beard - wesley.beard@mymail.champlain.edu
 * Michael Leonard - michael.leonard@mymail.chamamplain.edu
 * CSI-340 Final Project
 * 12/7/2020
 *
 * Written by Wes Beard
 *
 * This file stores all of the relevant information for the popup box
 */

package interactivity;

public class Popup {
    public static int x = 500;
    public static int y = 500;
    public static int width = 300;
    public static int height = 200;
    public static int buttonX = 500;
    public static int buttonY = 550;
    public static int buttonWidth = 100;
    public static int buttonHeight = 50;
    public static String buttonText = "Ok";
    public static String text;
}
